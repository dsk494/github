import javafx.animation.*;
import javafx.application.Application;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.scene.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.ScrollEvent;
import javafx.scene.media.AudioClip;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.scene.paint.PhongMaterial;
import javafx.scene.shape.Box;
import javafx.scene.shape.DrawMode;
import javafx.scene.shape.Ellipse;
import javafx.scene.shape.Sphere;
import javafx.scene.transform.Rotate;
import javafx.scene.transform.Translate;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.geometry.Pos;
import javafx.util.Duration;

import java.io.File;

//equation of an ellipse is (x-h)^2/a^2+(y-k)^2/b^2=1
public class Sphere3D extends Application {
    private boolean moonLeft = true;
    private boolean moonBackwards = true;

    private static final float WIDTH = 1400;
    private static final float HEIGHT = 1000;
    private static final int RADIUS_MOON = 70;
    private static final int HEIGHT_MOON = 70;
    private Rotate moonRotate;

    private static final int RADIUS_EARTH = 100;
    private static final int HEIGHT_EARTH = 20;
    private double anchorX, anchorY;
    private double anchorAngleX = 0;
    private double anchorAngleY = 0;
    private final DoubleProperty angleX = new SimpleDoubleProperty(0);
    private final DoubleProperty angleY = new SimpleDoubleProperty(0);
    private double asteroidX, asteroidY, asteroidZ;
    private double moonX, moonY, moonZ;

    @Override
    public void start(Stage stage) {

        PhongMaterial earthMaterial = new PhongMaterial();
        earthMaterial.setDiffuseMap(new Image(getClass().getResourceAsStream("/resources/earth/earth-d.jpg")));
        earthMaterial.setSelfIlluminationMap(new Image(getClass().getResourceAsStream("/resources/earth/earth-l.jpg")));
        earthMaterial.setSpecularMap(new Image(getClass().getResourceAsStream("/resources/earth/earth-s.jpg")));
        earthMaterial.setBumpMap(new Image(getClass().getResourceAsStream("/resources/earth/earth-n.jpg")));
//Earth pictures are from online, youtube video...
        PhongMaterial asteroidMaterial = new PhongMaterial();
        asteroidMaterial.setDiffuseMap(new Image(getClass().getResourceAsStream("resources/Asteroids/Asteroid-PNG-Transparent.png")));


        PhongMaterial moonMaterial2 = new PhongMaterial();
        moonMaterial2.setDiffuseMap(new Image(getClass().getResourceAsStream("resources/Asteroids/moon-png-5a3ad93db76ab1.00398271151380614175136308.jpg")));

        asteroidX = 600;
        asteroidY = -25;
        asteroidZ = 300;
        moonX = 100;
        moonY = -25;
        moonZ = 100;
        // Create a Sphere
        //Earth
        Sphere sphere = new Sphere(RADIUS_EARTH, HEIGHT_EARTH);
        sphere.setTranslateX(300);
        sphere.setTranslateY(-5);
        sphere.setTranslateZ(400);
        sphere.setRotationAxis(Rotate.Y_AXIS);
        sphere.setMaterial(earthMaterial);
//asteroid
        Sphere sphere2 = new Sphere(50, 10);
        sphere2.setTranslateX(asteroidX);
        sphere2.setTranslateY(asteroidY);
        sphere2.setTranslateZ(asteroidZ);
        sphere2.setRotationAxis(Rotate.Z_AXIS);
        sphere2.setMaterial(asteroidMaterial);


//moon
        Sphere sphere3 = new Sphere(RADIUS_MOON, HEIGHT_MOON);
        sphere3.setTranslateX(moonX);
        sphere3.setTranslateY(moonY);
        sphere3.setTranslateZ(moonZ);
        sphere3.setRotationAxis(Rotate.Y_AXIS);
        sphere3.setMaterial(moonMaterial2);


        Camera camera = new PerspectiveCamera(true);
        camera.setNearClip(1);
        camera.setFarClip(10000);
        camera.translateZProperty().set(-1000);
        Group world = new Group();
        world.getChildren().add(sphere);
        world.getChildren().add(sphere2);
        world.getChildren().add(sphere3);
        Group root = new Group();
        root.getChildren().add(world);
        root.getChildren().add(prepareImageView());


        Scene scene = new Scene(root, WIDTH, HEIGHT, true);
        scene.setFill(Color.SILVER);
        scene.setCamera(camera);


        initMouseControl(world, scene, stage);

        stage.setTitle("Dhruv's Astro Project");
        stage.setScene(scene);
        stage.show();
        sphere.setTranslateX(RADIUS_EARTH);
        sphere.setTranslateY(HEIGHT_EARTH);
        sphere3.translateXProperty().bind(sphere.translateXProperty());
        sphere3.translateYProperty().bind(sphere.translateYProperty().subtract(RADIUS_MOON));
        moonRotate = new Rotate(0, 0, RADIUS_MOON);
        sphere3.getTransforms().add(moonRotate);




//moon z-axis 100-700, x-axis:100-500, bool


        AnimationTimer timer = new AnimationTimer() {
            @Override
            public void handle(long now) {
                sphere.rotateProperty().set(sphere.getRotate() + 0.2);
                sphere2.rotateProperty().set(sphere.getRotate() + 0.3);
                sphere3.rotateProperty().set(sphere.getRotate() + 0.4);
                asteroidX--;




//
//                if (moonLeft) {
//
//
//
//                    moonX--;
//                    if (moonX == 175) {
//                        moonBackwards = true;
//                    }
//                    if (moonX < -100) {
//                        moonLeft = false;
//                        moonX = -100;
//                    }
//                } else {
//                    moonX++;
//                    if (moonX == 175) {
//                        moonBackwards = false;
//                    }
//                    if (moonX > 250) {
//                        moonLeft = true;
//                        moonX = 250;
//                    }
//                }
//                if (moonBackwards) {
//                    moonZ+=2;
//                } else {
//                    moonZ-=2;
//                }


                Timeline moonTimeline = new Timeline(
                        new KeyFrame(Duration.ZERO, new KeyValue(moonRotate.angleProperty(), 0)),
                        new KeyFrame(Duration.seconds(5), new KeyValue(moonRotate.angleProperty(), 360))
                );
                moonTimeline.setCycleCount(Timeline.INDEFINITE);
                 moonTimeline.play();

                System.out.println("Moon Left " + moonLeft);
                System.out.println("Moon Backwards " + moonBackwards);
                System.out.println("Moon X " + moonX);
                System.out.println("Moon Z " + moonZ);

                sphere3.setTranslateX(moonX);
                sphere3.setTranslateZ(moonZ);
                System.out.println(moonX);

                sphere2.setTranslateX(asteroidX);
                sphere2.setTranslateY(asteroidY);
                sphere2.setTranslateZ(asteroidZ);
                sphere2.setRotationAxis(Rotate.Z_AXIS);
                sphere2.setMaterial(asteroidMaterial);
                Sphere sphere3 = new Sphere(70, 30);

                sphere3.setTranslateY(moonY);
                sphere3.setTranslateZ(moonZ);
                sphere3.setRotationAxis(Rotate.X_AXIS);
                sphere3.setMaterial(moonMaterial2);


            }
        };
        timer.start();

    }



    private ImageView prepareImageView() {
        Image image = new Image(getClass().getResourceAsStream("/resources/galaxy/galaxy.jpg"));
        ImageView imageView = new ImageView(image);
        imageView.setPreserveRatio(true);
        imageView.getTransforms().add(new Translate(-image.getWidth() / 2, -image.getHeight() / 2, 800));
        return imageView;
    }

    private void initMouseControl(Group group, Scene scene, Stage stage) {
        Rotate xRotate;
        Rotate yRotate;
        group.getTransforms().addAll(
                xRotate = new Rotate(0, Rotate.X_AXIS),
                yRotate = new Rotate(0, Rotate.Y_AXIS)
        );
        xRotate.angleProperty().bind(angleX);
        yRotate.angleProperty().bind(angleY);

        scene.setOnMousePressed(event -> {
            anchorX = event.getSceneX();
            anchorY = event.getSceneY();
            anchorAngleX = angleX.get();
            anchorAngleY = angleY.get();
        });

        scene.setOnMouseDragged(event -> {
            angleX.set(anchorAngleX - (anchorY - event.getSceneY()));
            angleY.set(anchorAngleY + anchorX - event.getSceneX());
        });

        stage.addEventHandler(ScrollEvent.SCROLL, event -> {
            double delta = event.getDeltaY();
            group.translateZProperty().set(group.getTranslateZ() + delta);
        });





    }

    public static void main(String[] args) {
        launch(args);
    }
}
